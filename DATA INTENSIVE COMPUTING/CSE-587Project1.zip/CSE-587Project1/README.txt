Following are the steps followed for the analysis of Data using R. 

Page 38 :
1. Download data from URL specified.
2. Download R for analysis.
3. There are R scripts as Page38.R in src folder can be run.
4. You can see successfully the analysis done on it.


RealDirectCase Study:

1. Follow Steps 1-2 from above.
2. There is a R script realdirect.R that should be run.
3. You can see the final analysis after running it.


Twitter data analysis:

1. Download twitter data from http://www.infochimps.com/datasets/twitter-census-hashtags-urls-smileys-by-month.
2. Run the R script in src folder RscriptProject1.R
3. We have done analysis on this data according to the hastags, urls and smileys. You can see the desired results after running the script.


For looking at results without running the R scripts, you can go to Graphs folder and see it.

 
