#Answer 1 (Page 38)

getwd()
setwd("C:/Users/SIDDHARTH/Desktop/dds_ch2_nyt")

nyt1 <- read.csv("nyt1.csv")
View(nyt1)

# Question 1
nyt1$age_group <- cut(nyt1$Age, c(-Inf,0,18,24,34,44,54,64,Inf))
View(nyt1)

# Question 2
# Part 1
library(ggplot2)
ggplot(nyt1, aes(x=Impressions, fill=age_group)) + geom_histogram(binwidth=2)
ggplot(nyt1, aes(x=age_group, y=Impressions, fill=age_group)) + geom_boxplot()

ggplot(nyt1, aes(x=Clicks/Impressions, fill=age_group)) + geom_histogram(binwidth=2)
ggplot(nyt1, aes(x=age_group, y=Clicks/Impressions, fill=age_group)) + geom_boxplot()

# Part 2
nyt1$click_group <- cut(nyt1$Clicks, c(-Inf,0,1,2,3,4,5,Inf))
View(nyt1)

#Part 3
ggplot(subset(nyt1,Age>0), aes(x = age_group,y = Clicks, fill =age_group)) + geom_histogram(stat ="identity",binwidth=2)
ggplot (nyt1, aes(x = click_group, y = Clicks, fill = age_group)) + geom_histogram(stat ="identity",binwidth=2)
ggplot(subset(nyt1,Age > 0 & Clicks >  1 ), aes(x=Clicks, colour=age_group)) + geom_density()
ggplot( subset(nyt1, Gender==0 & Age>0 ), aes(x = age_group,y = Clicks, fill =age_group)) + geom_histogram(stat ="identity",binwidth=2)
ggplot(subset(nyt1, Gender==0 & Age>0), aes(x = age_group,y = Impressions, fill =age_group)) + geom_histogram(stat ="identity",binwidth=2)
ggplot( subset(nyt1, Gender==1 & Age>0 ), aes(x = age_group,y = Clicks, fill =age_group)) + geom_histogram(stat ="identity",binwidth=2)
ggplot(subset(nyt1, Gender==1 & Age>0), aes(x = age_group,y = Impressions, fill =age_group)) + geom_histogram(stat ="identity",binwidth=1)
ggplot(subset(nyt1,Age > 0  ), aes(x=Impressions, colour=age_group)) + geom_density()
ggplot(subset(nyt1,Age > 0 & Clicks >  1 ), aes(x=age_group, colour=click_group)) + geom_density()
ggplot(nyt1, aes(x = age_group,y = Signed_In, fill =age_group))+geom_histogram(stat ="identity",binwidth=1)
ggplot(subset(nyt1, (Age>0 & Age < 18) | (Age > 64 & Age < Inf) ), aes(x = age_group,y = Impressions, fill =age_group)) + geom_histogram(stat ="identity",binwidth=1)
ggplot(nyt1, aes(x = Gender,y = Impressions, fill =age_group, order=age_group)) + geom_histogram(stat ="identity",binwidth=1)
ggplot(nyt1, aes(x = Gender,y = Impressions, fill =Signed_In, order=Signed_In)) + geom_histogram(stat ="identity",binwidth=1)
ggplot(nyt1, aes(x = Gender,y = Signed_In, fill =age_group, order = age_group)) + geom_histogram(stat ="identity",binwidth=1)

#Part 4
install.packages("doBy")
library(doBy)
stats <- function(metrics){c(Length=length(metrics),Mean= mean(metrics),Maximum= max(metrics), Standard_Deviation = sd(metrics), Variance = var(metrics))}
summaryBy(Age~age_group, data =nyt1, FUN=stats)
summaryBy(Clicks~age_group, data =nyt1, FUN=stats)
summaryBy(Impressions~age_group, data =nyt1, FUN=stats)

summaryBy(Clicks~click_group, data =nyt1, FUN=stats)
summaryBy(Age~click_group, data =nyt1, FUN=stats)
summaryBy(Impressions~click_group, data =nyt1, FUN=stats)

summaryBy(Clicks/Impressions~age_group, subset(nyt1,nyt1$Impressions > 0 & nyt1$Clicks > 0), FUN=stats)

summaryBy(Gender+Signed_In+Impressions+Clicks~age_group,data =nyt1)

#Question 3
nyt10 <- read.csv("nyt10.csv")
nyt10$age_group <- cut(nyt10$Age, c(-Inf,0,18,24,34,44,54,64,Inf))
ggplot(subset(nyt10,Age>0), aes(x = age_group,y = Clicks, fill =age_group)) + geom_histogram(stat ="identity",binwidth=2)
ggplot(subset(nyt10,Age>0), aes(x = age_group,y = Impressions, fill =age_group)) + geom_histogram(stat ="identity",binwidth=2)
ggplot(subset(nyt10,Age>0), aes(x = age_group,y = Signed_In, fill =age_group)) + geom_histogram(stat ="identity",binwidth=2)
