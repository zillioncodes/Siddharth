#source file for count of Hashtag 
monthly.data <- read.delim("H:/New folder (2)/infochimps_dataset_11897_download_15372-tsv/tokens_by_month/monthly-data", header=F)

#subet of dataset on the basic of TweetType
HashtagMonthly =subset(monthly.data,monthly.data=='hashtag')
smileyMonthly =subset(monthly.data,monthly.data=='smiley')
tweet_urlMonthly =subset(monthly.data,monthly.data=='tweet_url')





TopTweet_url=subset(tweet_urlMonthly,tweet_urlMonthly$V3>5000)


#Year wise split
Year2009=subset(monthly.data,monthly.data$V2>200900 & monthly.data$V2<200913)




tweet_urlMonthly=subset(tweet_urlMonthly,tweet_urlMonthly$V3>1)
UHTM=aggregate(V3~V4, data=HashtagMonthly,FUN=sum)
UTURLM=aggregate(V3~V4, data=tweet_urlMonthly,FUN=sum)
USM=aggregate(V3~V4, data=smileyMonthly,FUN=sum)
TUHT=subset(UHTM,UHTM$V3>10000)

TUHT=subset(UHTM,UHTM$V3>10000)

TUURL=subset(UTURLM,UTURLM$V3>500)
TUS=subset(USM,USM$V3>5000)



require(ggplot2)

STHT=TUHT[order(-V3),]
STHT=TUHT[order(-TUHT$V3),]
STURL=TUURL[order(-TUURL$V3),]
STS=TUS[order(-TUS$V3),]




qplot(STHT$V4,STHT$V3,geom="bar",fill=STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.x=theme_text(angle=-90,size=12))
qplot(STHT$V4,STHT$V3,geom="bar",fill=-STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.x=theme_text(angle=-90,size=12))
qplot(STHT$V4,STHT$V3,geom="hist",fill=-STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.x=theme_text(angle=-90,size=12))
qplot(STHT$V4,STHT$V3,geom="histogram",fill=-STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.x=theme_text(angle=-90,size=12))
qplot(STHT$V3,STHT$V4,geom="histogram",fill=-STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.x=theme_text(angle=-90,size=12))
qplot(STHT$V3,STHT$V4,geom="histogram",fill=-STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.y=theme_text(angle=-90,size=12))
qplot(STHT$V4,STHT$V3,geom="histogram",fill=-STHT$V3,xlab="HashTag",ylab="Count",position="dodge")+opts(axis.text.x=theme_text(angle=-90,size=12))
qplot(STHT$V4,STHT$V3,geom="histogram",fill=-STHT$V3,xlab="HashTag",ylab="Count",order=STHT$V3)+opts(axis.text.x=theme_text(angle=-90,size=12))
qplot(STHT$V4,STHT$V3,geom="histogram",fill=-STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.x=theme_text(angle=-90,size=12))+geom_bar(aes(weights=STHT$V3), position="dodge")
qplot(STHT$V3,geom="histogram",fill=-STHT$V3,xlab="HashTag",ylab="Count")+opts(axis.text.x=theme_text(angle=-90,size=12))+geom_bar(aes(weights=STHT$V3), position="dodge")


#Year wise Hashtag
Ht2009=subset(HashtagMonthly,HashtagMonthly$V2>200900 & HashtagMonthly$V2<200913)
Ht2008=subset(HashtagMonthly,HashtagMonthly$V2>200800 & HashtagMonthly$V2<200813)
Ht2007=subset(HashtagMonthly,HashtagMonthly$V2>200700 & HashtagMonthly$V2<200713)

#Year wise Smiley
S2009=subset(smileyMonthly,smileyMonthly$V2>200900 & smileyMonthly$V2<200913)
S2008=subset(smileyMonthly,smileyMonthly$V2>200800 & smileyMonthly$V2<200813)
S2007=subset(smileyMonthly,smileyMonthly$V2>200700 & smileyMonthly$V2<200713)
S2006=subset(smileyMonthly,smileyMonthly$V2>200600 & smileyMonthly$V2<200613)

#Year wise Tweet-url
URL2006=subset(tweet_urlMonthly,tweet_urlMonthly$V2>200600 & tweet_urlMonthly$V2<200613)
URL2007=subset(tweet_urlMonthly,tweet_urlMonthly$V2>200700 & tweet_urlMonthly$V2<200713)
URL2008=subset(tweet_urlMonthly,tweet_urlMonthly$V2>200800 & tweet_urlMonthly$V2<200813)
URL2009=subset(tweet_urlMonthly,tweet_urlMonthly$V2>200900 & tweet_urlMonthly$V2<200913)

spec2009=[sum(Ht2009$V3),sum(S2009$V3),sum(URL2009$V3)]
spec2009=(sum(Ht2009$V3),sum(S2009$V3),sum(URL2009$V3))
spec2009<-(sum(Ht2009$V3),sum(S2009$V3),sum(URL2009$V3))
spec2009<-table(sum(Ht2009$V3),sum(S2009$V3),sum(URL2009$V3))

library(plotrix)
install(plotrix)
install.packages("plotrix")
pie3D(spec2009,lbs,explode=0.2,main="Pie chart of tweets in 2009")
library(plotrix)


#Pie chart plot year-wise -2009
pie3D(spec2009,labels=lbs,explode=0.1,main="Pie chart of tweets in 2009")
#Pie-chart 2008
spec2008<-c(sum(Ht2008$V3),sum(S2008$V3),sum(URL2008$V3))
pie3D(spec2008,labels=lbs,explode=0.1,main="Pie chart of tweets in 2008")
# Year2007
spec2007<-c(sum(Ht2007$V3),sum(S2007$V3),sum(URL2007$V3))

pie3D(spec2007,labels=lbs,explode=0.2,main="Pie chart of tweets in 2007")

# Wordcloud
install.packages("wordcloud")
require("wordcloud")
require("ggplot2")
wordcloud(STHT$V4, STHT$V3, random.order=FALSE, colors=brewer.pal(8, "Dark2"))
wordcloud(TUS$V4, TUS$V3, random.order=FALSE, colors=brewer.pal(8, "Dark2"))
wordcloud(STURL$V4, STURL$V3, random.order=FALSE, colors=brewer.pal(8, "Dark2"))
save.image("C:/Users/SIDDHARTH/Desktop/Spring-Courses/DIC/Type/Rdata-Type.RData")

#stacked bar plot
spec<-rbind(spec2009,spec2008,spec2007)
barchart(spec2009+spec2008+spec2007~V1,data=tspec)


#wordmap
location <- read.table("C:/Users/Mayank/Desktop/location.xlsx", header=T, quote="\"")
mapPoints <- ggmap(Winter_Map_NewYork) + geom_point(data = location ,aes(x = V1, y = V2, size = V3), alpha = 0.7,colour="blue")
library(ggmap)
library(rworldmap)
library(RgoogleMaps)
library(mapproj)
Winter <- get_map(location = 'United States', zoom = 3)
mapPoints <- ggmap(Winter) + geom_point(data = location ,aes(x = V2, y = V1), alpha = 0.4,colour="red")
mapPoints
mat = as.matrix(x)
kclus <- kmeans(mat,4)
mat2 = data.frame(x)
mapPoints_KMeans <- ggmap(map) +
geom_point(data = mat2 ,aes(x = location$V2,
y = location$V1 , col =kclus$cluster ))
mapPoints_KMeans

#Sentiment
happy=subset(Topsmiley,Topsmiley$V4==":)"|Topsmiley$V4=="(:"|Topsmiley$V4==":-)"|Topsmiley$V4==":]")
sad=subset(Topsmiley,Topsmiley$V4=="):"|Topsmiley$V4==":("|Topsmiley$V4==":-("|Topsmiley$V4==":/"|Topsmiley$V4==":|"|Topsmiley$V4=="=/")
neutral=subset(Topsmiley,Topsmiley$V4==":&apos;("|Topsmiley$V4==":-d"|Topsmiley$V4==":o)"|Topsmiley$V4=="d:"|Topsmiley$V4=="d:"|Topsmiley$V4=="=p"|Topsmiley$V4=="=d")
count<-c(sum(happy$V3),sum(sad$V3),sum(neutral$V3))
qplot(c("positive Sentiments","negative sentiments","Undefined"),fill=-count, count, xlab="Sentiments",ylab="level")+geom_bar()


