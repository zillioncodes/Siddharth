getwd()
setwd("C:/Users/Mayank/Desktop/DATA/doing_data_science-master/doing_data_science-master/dds_datasets/dds_ch2_rollingsales")
library(sqldf)
####------------------------save all 
manhat <- read.csv(file="rollingsales_manhattan.csv")
brok <- read.csv(file="rollingsales_brooklyn.csv")
queens <- read.csv(file="rollingsales_queens.csv")
bronx <- read.csv(file="rollingsales_bronx.csv")
statiland <- read.csv(file="rollingsales_statenisland.csv")

combined_data_NY <- rbind(manhat,brok,queens,bronx,statiland)


##########-----------------brooklyn data-------------
summary(brok)

# changing $1234 to 1234
brok$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",brok$SALE.PRICE))
brok$land.sqft <- as.numeric(gsub("[^[:digit:]]","",brok$LAND.SQUARE.FEET))
queens$sale.date <- as.Date(as.character(queens$SALE.DATE),"%m/%d/%y")

attach(brok) ## attach to same work space and use variable
hist(SALE.PRICE.N)
hist(SALE.PRICE.N[SALE.PRICE.N>0])
hist(land.sqft[SALE.PRICE.N==0])
detach(brok)

brok.sale <- brok[brok$SALE.PRICE.N!=0,]#### create a new work sheet
plot(brok.sale$land.sqft,brok.sale$SALE.PRICE.N)

plot(log(brok.sale$land.sqft),log(brok.sale$SALE.PRICE.N))
brok.homes <- brok.sale[which(grepl("FAMILY",brok.sale$BUILDING.CLASS.CATEGORY)),] # grep, grepl, regexpr and gregexpr search for matches to argument pattern within each element of a character vector: they differ in the format of and amount of detail in the results.sub and gsub perform replacement of the first and all matches respectively. 

plot(log(brok.homes$land.sqft),log(brok.homes$SALE.PRICE.N))
brok.homes[which(brok.homes$SALE.PRICE.N<100000),][order(brok.homes[which(brok.homes$SALE.PRICE.N<100000),]$SALE.PRICE.N),]

brok.homes$outliers <- (log(brok.homes$SALE.PRICE.N) <=5) + 0
brok.homes <- brok.homes[which(brok.homes$outliers==0),]
plot(log(brok.homes$land.sqft),log(brok.homes$SALE.PRICE.N),col = "red",main= "brooklyn homes Vs sale prize")

attach(brok.homes)
brok.homes$price_scale[brok.homes$SALE.PRICE.N < 500000] <- "Mild(<2.5)"
brok.homes$price_scale[brok.homes$SALE.PRICE.N >=500000 & brok.homes$SALE.PRICE.N < 1000000] <- "Average(2.5 to 5.0)"
brok.homes$price_scale[brok.homes$SALE.PRICE.N >= 1000000] <- "High(>5.0)"
detach(brok.homes)
head(brok.homes)

Pie_ChartData_Brok = sqldf("Select distinct(price_scale),count(price_scale)
                           from brok.homes group by price_scale")

pie3D(Pie_ChartData_Brok[[2]],labels = Pie_ChartData_Brok[[1]],radius=0.8,height=0.1,theta=pi/5,
      start=1,border=par("fg"),labelcex=1.0,explode =0.2 , 
      main="Distribution of Sale Price Data Recorded \n over Broklyn")

#---------------------------manhattan------------------------------

summary(manhat)

manhat$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",manhat$SALE.PRICE)) # changing $1234 to 1234

manhat$land.sqft <- as.numeric(gsub("[^[:digit:]]","",manhat$LAND.SQUARE.FEET))
manhat$sale.date <- as.Date(as.character(manhat$SALE.DATE),"%m/%d/%y")

attach(manhat) ## attach to same work space and use variable
hist(SALE.PRICE.N)
hist(SALE.PRICE.N[SALE.PRICE.N>0])
hist(land.sqft[SALE.PRICE.N==0])
detach(manhat)

manhat.sale <- manhat[manhat$SALE.PRICE.N!=0,]#### create a new work sheet
plot(manhat.sale$land.sqft,manhat.sale$SALE.PRICE.N)
plot(log(manhat.sale$land.sqft),log(manhat.sale$SALE.PRICE.N))

manhathomes <- manhat.sale[which(grepl("FAMILY",manhat.sale$BUILDING.CLASS.CATEGORY)),] # grep, grepl, regexpr and gregexpr search for matches to argument pattern within each element of a character vector: they differ in the format of and amount of detail in the results.sub and gsub perform replacement of the first and all matches respectively. 
plot(log(manhathomes$land.sqft),log(manhathomes$SALE.PRICE.N))

manhathomes[which(manhathomes$SALE.PRICE.N<100000),][order(manhathomes[which(manhathomes$SALE.PRICE.N<100000),]$SALE.PRICE.N),]

manhathomes$outliers <- (log(manhathomes$SALE.PRICE.N) <=5) + 0
manhathomes <- manhathomes[which(manhathomes$outliers==0),]
plot(log(manhathomes$land.sqft),log(manhathomes$SALE.PRICE.N))


###################----------------queens----------------


summary(queens)

queens$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",queens$SALE.PRICE)) # changing $1234 to 1234

queens$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",queens$SALE.PRICE))
queens$land.sqft <- as.numeric(gsub("[^[:digit:]]","",queens$LAND.SQUARE.FEET))
queens$sale.date <- as.Date(as.character(queens$SALE.DATE),"%m/%d/%y")

attach(queens) ## attach to same work space and use variable
hist(SALE.PRICE.N)
hist(SALE.PRICE.N[SALE.PRICE.N>0])
hist(land.sqft[SALE.PRICE.N==0])
detach(queens)

queens.sale <- queens[queens$SALE.PRICE.N!=0,]#### create a new work sheet
plot(queens.sale$land.sqft,queens.sale$SALE.PRICE.N)
plot(log(queens.sale$land.sqft),log(queens.sale$SALE.PRICE.N))

queens.homes <- queens.sale[which(grepl("FAMILY",queens.sale$BUILDING.CLASS.CATEGORY)),] # grep, grepl, regexpr and gregexpr search for matches to argument pattern within each element of a character vector: they differ in the format of and amount of detail in the results.sub and gsub perform replacement of the first and all matches respectively. 
plot(log(queens.homes$land.sqft),log(queens.homes$SALE.PRICE.N))

queens.homes[which(queens.homes$SALE.PRICE.N<100000),][order(queens.homes[which(queens.homes$SALE.PRICE.N<100000),]$SALE.PRICE.N),]

queens.homes$outliers <- (log(queens.homes$SALE.PRICE.N) <=5) + 0
queens.homes <- queens.homes[which(queens.homes$outliers==0),]
plot(log(queens.homes$land.sqft),log(queens.homes$SALE.PRICE.N))


##############--------------------------Total Data analysis--------------

summary(combined_data_NY)

# changing $1234 to 1234
combined_data_NY$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",combined_data_NY$SALE.PRICE))
combined_data_NY$land.sqft <- as.numeric(gsub("[^[:digit:]]","",combined_data_NY$LAND.SQUARE.FEET))
combined_data_NY$sale.date <- as.Date(as.character(combined_data_NY$SALE.DATE),"%m/%d/%y")

attach(combined_data_NY) ## attach to same work space and use variable
hist(SALE.PRICE.N)
hist(SALE.PRICE.N[SALE.PRICE.N>0])
hist(land.sqft[SALE.PRICE.N==0])
detach(combined_data_NY)

combined_data_NY.sale <- combined_data_NY[combined_data_NY$SALE.PRICE.N!=0,]#### create a new work sheet
plot(combined_data_NY.sale$land.sqft,combined_data_NY.sale$SALE.PRICE.N)

plot(log(combined_data_NY.sale$land.sqft),log(combined_data_NY.sale$SALE.PRICE.N))
combined_data_NY.homes <- combined_data_NY.sale[which(grepl("FAMILY",combined_data_NY.sale$BUILDING.CLASS.CATEGORY)),] # grep, grepl, regexpr and gregexpr search for matches to argument pattern within each element of a character vector: they differ in the format of and amount of detail in the results.sub and gsub perform replacement of the first and all matches respectively. 

plot(log(combined_data_NY.homes$land.sqft),log(combined_data_NY.homes$SALE.PRICE.N))
combined_data_NY.homes[which(combined_data_NY.homes$SALE.PRICE.N<100000),][order(combined_data_NY.homes[which(combined_data_NY.homes$SALE.PRICE.N<100000),]$SALE.PRICE.N),]

combined_data_NY.homes$outliers <- (log(combined_data_NY.homes$SALE.PRICE.N) <=5) + 0

combined_data_NY.homes <- combined_data_NY.homes[which(combined_data_NY.homes$outliers==0),]
plot(log(combined_data_NY.homes$land.sqft),log(combined_data_NY.homes$SALE.PRICE.N))