TweetCollector
==============

A Simple Project to Aggregate Data from the Twitter Streaming APIs
