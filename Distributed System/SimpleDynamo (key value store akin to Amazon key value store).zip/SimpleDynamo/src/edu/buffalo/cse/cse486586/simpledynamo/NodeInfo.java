package edu.buffalo.cse.cse486586.simpledynamo;

public class NodeInfo {
    String succ1;
    String succ2;
    String pred1;
    String pred2;
    String matchingNode;
NodeInfo(){}
}
